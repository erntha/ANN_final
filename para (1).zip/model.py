import matplotlib.pyplot as plt
import scipy.io.wavfile as wav

# Load the audio file (replace 'your_file_path' with the path to your .wav file)
file_path = '/home/eren/Desktop/para/tura/1_61cm_yazi.wav'
fs, data = wav.read(file_path)

# Ensure that if the file is stereo, we use only one channel
if len(data.shape) > 1:
    data = data[:,0]

# Plotting the spectrogram without labels or axes
plt.figure(figsize=(10, 4))
plt.specgram(data, Fs=fs, NFFT=1024, noverlap=512, cmap='winter')
plt.axis('off')  # Removes the axes and labels
plt.show()